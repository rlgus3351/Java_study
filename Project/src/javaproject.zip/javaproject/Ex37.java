package javaproject;

import java.util.Scanner;

public class Ex37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 3! = 1*2*3 = 6

		Scanner sc = new Scanner(System.in);
		System.out.print("정수 입력:");
		int num = sc.nextInt();

		int result = 0;
		for (int i = 1, j = 1; i <= num; i++) {
			j *= i;
			result = j;
		}
		System.out.println(num + "! : " + result);
	}

}
