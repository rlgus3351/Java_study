package javaproject;

public class Ex33 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int base = 2;
		int n = 3;
		int result = powerN(3, 3);
		System.out.println("결과 확인 : " + result);

	}

	public static int powerN(int base, int n) {
		int result = base;
		for (int i = 1; i < n; i++) {
			result *= base;
		}
		return result;
	}

}
