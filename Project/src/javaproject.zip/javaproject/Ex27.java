package javaproject;

import java.util.Arrays;
import java.util.Scanner;

public class Ex27 {

	public static void main(String[] args) {
		// 5개의 정수를 입력 받아 오름차순 정렬하여 출력하는 프로그램을 구현하시오.
		int[] temp = new int[5];

		Scanner sc = new Scanner(System.in);
		for(int i=0; i<temp.length; i++) {
			System.out.print((i+1) + "번째 수 입력 : ");
			temp[i] = sc.nextInt();
		}
//		System.out.println(Arrays.toString(temp));

		System.out.println("정렬 후");
		
		Arrays.sort(temp);
		for(int arr: temp) {
			System.out.print(arr + " ");

		}
	
	

	}

}
