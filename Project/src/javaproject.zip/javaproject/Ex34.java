package javaproject;

import java.util.Arrays;
import java.util.Scanner;

public class Ex34 {
	public static void main(String[] args) {
		// 문제. 문자열 형태의 2진수를 입력받아 10진수로 바꾸는 프로그램을 작성하시오.
		Scanner sc = new Scanner(System.in);
		System.out.println("2진수를 입력하세요.");
		String str = sc.next();
		String[] array = str.split("");

		// 2진수 자리별로 값을 넣어줌
		int[] num = new int[array.length];
		for (int i = 0; i < array.length; i++) {
			if (i == 0) {
				num[array.length - 1] = 1;
			} else {
				num[array.length - 1 - i] = powerN(2, i);
			}
		}
		System.out.print(str + "(2)" + " = ");
		int sum = 0;

		for (int i = 0; i < array.length; i++) {
			if (array[i].equals("1")) {
				sum += num[i] * 1;
			}
		}
		System.out.print(sum + "(10)");
	}

	public static int powerN(int base, int n) {
		int result = base;
		for (int i = 1; i < n; i++) {
			result *= base;
		}
		return result;
	}

}
