package javaproject;

import java.util.Arrays;
import java.util.Scanner;

public class Ex31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.print("첫 번째 숫자 입력 >>");
		int num1 = sc.nextInt();
		System.out.print("두 번째 숫자 입력 >>");
		int num2 = sc.nextInt();

		int[] array = { 100, 10, 1 };
		int[] count = new int[3];
		for (int i = 0; i < array.length; i++) {
			if (num2 % array[i] >= 0) {
				count[i] = num2 / array[i];
				num2 %= array[i];
			}
		}
		int sum = 0;
		for (int i = 0; i < count.length; i++) {
			System.out.println(num1 * count[count.length - 1 - i]);
			sum += array[i] * num1 * count[i];
		}
		System.out.println(sum);

	}

}
