package javaproject;

import java.util.Scanner;

public class Ex23 {
	public static void main(String[] args) {
		//단 수와 곱해지길 원하는 수를 입력하여 이와 같이 출력되게 하시오
		//예시
		//단수 입력 : 
		//2
		// 어느수 까지 출력 : 
		// 2단 2*1 =2 ~ 2*6 = 12
		
		Scanner sc = new Scanner(System.in);
		System.out.println("단수 입력 : ");
		int num = sc.nextInt();
		System.out.println("어느수 까지 출력 : ");
		int rows = sc.nextInt();
		
		System.out.printf("%d단\n", num);
		
		for(int i=1; i<=rows; i++) {
			System.out.printf("%d*%d=%d\n", num, i, num*i);
		}
		
	}

}
