package javaproject;

import java.util.Arrays;
import java.util.Scanner;

public class Ex36 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println("==== 알파벳 빈도수 구하기 ====");
//		System.out.print("입력 >> ");
//		String str = sc.next();
//		String temp = str.toCase();

		// A 65 - Z 90 | a -97 z - 122;
		Scanner sc = new Scanner(System.in);
		System.out.println("==== 알파벳 빈도수 구하기 ====");
		System.out.print("입력 >>> ");

		int[] word_count = new int[26];
		String text = sc.nextLine();
		String lowerText = text.toLowerCase();
		String alphabet = "abcdefghijklmnopqrstuvwxyz";
		for (int i = 0; i < lowerText.length(); i++) {
			for (int j = 0; j < alphabet.length(); j++) {
				if (lowerText.charAt(i) == alphabet.charAt(j)) {
					word_count[j] += 1;
				}
			}
		}

		for (int i = 0; i < word_count.length; i++) {
			System.out.println((char) ('a' + i) + ":" + word_count[i]);
		}
	}

}
