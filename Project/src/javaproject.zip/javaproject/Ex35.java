package javaproject;

import java.util.Random;
import java.util.Scanner;

public class Ex35 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Random r = new Random();
		int cnt = 0;
		boolean isOver = true;
		while (isOver) {
			int num1 = r.nextInt(10) + 1;
			int num2 = r.nextInt(10) + 1;
			System.out.printf("%d + %d = ", num1, num2);
			int answer = sc.nextInt();
			if (num1 + num2 == answer) {
				System.out.println("SUCCEESS!");
			} else {
				System.out.println("Fail...");
				cnt++;
			}
			if (cnt >= 5) {
				isOver = false;
				System.out.print("GAME OVER!");
			}
		}
	}
}
