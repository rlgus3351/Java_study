package javaproject;

import java.util.Arrays;
import java.util.Scanner;

public class Ex32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 0일때 cnt ++
		// x일때 cnt 초기화 0, cnt++

		System.out.println("========채점 하기=========");
		Scanner sc = new Scanner(System.in);

		String answer = sc.next();
		String[] array = answer.split("");
		int cnt = 0;
		int sum = 0;

		for (int i = 0; i < array.length; i++) {
			if (array[i].equals("O") || array[i].equals("o")) {
				cnt++;
				sum += cnt;
			} else {
				cnt = 0;
			}
		}

		System.out.println(sum);

	}

}
