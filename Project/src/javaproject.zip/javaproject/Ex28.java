package javaproject;

public class Ex28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int cnt = 1;
		int[][] array = new int[5][5];

		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				array[array[i].length - 1 - j][i] = cnt;
				cnt++;
			}
		}

		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				System.out.print(array[i][j] + " ");
			}
			System.out.println();
		}
	}

}
