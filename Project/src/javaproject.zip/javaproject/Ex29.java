package javaproject;

import java.util.Scanner;

public class Ex29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		// N 입력
		System.out.print("N 입력 >>");
		int n = sc.nextInt();

		System.out.print("X 입력 >>");
		int x = sc.nextInt();

		int[] array = new int[n];

		for (int i = 0; i < n; i++) {
			System.out.print((i + 1) + "번째 정수 입력 >>");
			array[i] = sc.nextInt();
		}
		System.out.print("결과 >> ");
		for (int i = 0; i < array.length; i++) {
			if (array[i] < x) {
				System.out.print(array[i] + " ");
			}
		}

	}

}
