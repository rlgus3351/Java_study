package javaproject;

public class Ex26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//---------------------------------------case 1-------------------------------------//
		for(int i=0; i<5; i++) {
			for(int j=4; j>i; j--) {
				System.out.print(" ");
			}
			for(int k=0; k<i+1; k++) {
				System.out.print("*");
			}
			System.out.println();
			
//----------------------------------------case 2------------------------------------//
			System.out.println("    *");
			System.out.println("   **");
			System.out.println("  ***");
			System.out.println(" ****");
			System.out.println("*****");
			
		}
	}

}
