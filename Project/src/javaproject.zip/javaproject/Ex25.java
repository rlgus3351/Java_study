package javaproject;

import java.util.Random;

public class Ex25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] point = { 92, 32, 52, 9, 81, 2, 68 };
		Random r = new Random();
		int min = 0;
		int distance = 0;
		int index = 0;

		int num1 = r.nextInt(8);
		int num2 = r.nextInt(8);

		if (num1 != num2) {
			System.out.println(num1);
			System.out.println(num2);
		}
		if (num1 > num2) {
			min = point[num2];
			distance = num1 - num2;
			for (int i = num2; i <= num1; i++) {
				if (min > point[i]) {
					min = point[i];
				}
			}
		}
		if (num2 > num1) {
			min = point[num1];
			distance = num2 - num1;
			for (int i = num1; i <= num2; i++) {
				if (min > point[i]) {
					min = point[i];
				}
			}
		}

		for (int i = 0; i < point.length; i++) {
			if (min == point[i]) {
				index = i;
			}
		}

		System.out.printf("result = [%d,%d]", distance, index);

	}

}
